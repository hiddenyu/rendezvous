# rendezvous
Since the beginning of time, the moon has been governed by LOONA, a group of twelve girls, since the beginning  of time. However, when all twelve girls go missing, it is up to a young star, Orbit, to regather the missing girls and use their powers to restore balance to the world.
## overview
*rendezvous* is a platformer inspired by the storyline of the k-pop girl group, LOONA. It involves the player, named Orbit, collecting twelve colored crystals to complete the game, through jumping on platformers, learning new abilities, and exploring different worlds.

The game also includes a mode where platforms and terrain are randomly generated, a way for players to test their abilities and see how many crystals they can get in certain timeframes.
## usage
The game runs locally and requires the cmu_graphics library.
- the font 'BaksoSapi' was used by changing a part of the *shape_logic.py* file in cmu_graphics; the font file is included as well

To run the game, download all the files and run the file named *main.py*
- Press 'r' at any time to restart the game and go back to the starting screen!
